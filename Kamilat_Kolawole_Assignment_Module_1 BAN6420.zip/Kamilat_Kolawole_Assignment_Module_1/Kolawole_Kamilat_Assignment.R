# Highridge Construction Company - Payment Slips (R Version)
# Name: Kamilat Kolawole Olabisi

set.seed(123)

# Create 400 workers
id <- 1:400
name <- paste("worker", id, sep = "_")
salary <- sample(5000:30000, 400, replace = TRUE)
gender <- sample(c("Male", "Female"), 400, replace = TRUE)

workers <- data.frame(id, name, salary, gender)

# Create folder
if (!dir.exists("Payment_Slips_R")) {
  dir.create("Payment_Slips_R")
}

# Loop and generate slips
for (i in 1:nrow(workers)) {
  w <- workers[i, ]
  
  if (w$salary > 10000 & w$salary < 20000) {
    level <- "A1"
  } else if (w$salary > 7500 & w$salary < 30000 & w$gender == "Female") {
    level <- "A5-F"
  } else {
    level <- "Standard"
  }
  
  slip <- paste(
    "Payment Slip\n",
    "-------------\n",
    "Name: ", w$name, "\n",
    "ID: ", w$id, "\n",
    "Gender: ", w$gender, "\n",
    "Salary: $", w$salary, "\n",
    "Employee Level: ", level, "\n",
    sep = ""
  )
  
  filename <- paste0("Payment_Slips_R/", w$name, "_slip.txt")
  writeLines(slip, filename)
}

cat("R payment slips created successfully!\n")
