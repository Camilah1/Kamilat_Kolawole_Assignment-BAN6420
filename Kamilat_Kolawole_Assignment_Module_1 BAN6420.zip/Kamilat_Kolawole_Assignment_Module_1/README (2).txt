# Highridge Construction Company - Payment Slip Project
This project was done for my BAN6420 Module 1 assignment.  
I used both Python and R to create weekly payment slips for 400 workers.

## What the program does
- Creates 400 workers automatically.
- Each worker gets a random salary and a gender.
- I used a loop to go through each worker.
- Based on the salary and gender rules given in the assignment, the program assigns the correct employee level:
  - A1 = salary between 10,000 and 20,000  
  - A5-F = salary between 7,500 and 30,000 AND must be Female  
  - Standard = everyone else
- The program saves a text file for each worker as their payment slip.

## Files Included
- `payment_slips.py` → Python version  
- `payment_slips.R` → R version  
- Folders where the slips will be saved:
  - `Payment_Slips_Python/`
  - `Payment_Slips_R/`

## How to Run the Python Code
Open your terminal and run:



## How to Run the R Code
Open R or RStudio and run:



## Notes
I added simple exception handling in Python so the program does not stop if one slip fails.

This assignment helped me practice:
- loops  
- conditions  
- file handling  
- Python and R basics  

